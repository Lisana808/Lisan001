import React from 'react';

export default function App() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>Lisan+</h1>
      <p>Welcome to your immersive Arabic experience.</p>
    </div>
  );
}
